# CampusRide Backend – Smart College Bus Management

FastAPI + PostgreSQL (pgvector) + MongoDB. Pairs with the CampusRide website.

## Run it
The backend serves the website too: after starting, open **http://localhost:8000** (website) or **/docs** (API). Register a student account or sign in as the demo admin to see the Admin tab.

**Fastest (no databases needed – SQLite + in-memory reports):**
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload          # http://localhost:8000/docs
```
**Full stack (PostgreSQL + MongoDB + Prometheus + Grafana):**
```bash
docker compose up --build              # API :8000 · Prometheus :9090 · Grafana :3000
```
Demo admin: `admin@campus.edu` / `admin12345` (change in `.env`). Demo data matches the website.

**Try it:**
```bash
TOKEN=$(curl -s -X POST localhost:8000/auth/login -d "username=admin@campus.edu&password=admin12345" | python -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
curl -H "Authorization: Bearer $TOKEN" "localhost:8000/student/arrivals?stop=Kukatpally&direction=in&at=07:00"
```
Tests: `pip install -r requirements-dev.txt && pytest --cov=app`

## Main endpoints
`POST /auth/register|login` · `GET /auth/me` · `GET|POST|DELETE /drivers /routes /buses /schedules` (writes = admin) · `GET /student/stops|arrivals|live` · `POST /student/reports` · `GET /student/notices/search|ask` · `POST /student/notices` (admin) · `GET /admin/analytics/trips|audit` · `GET /health` · `GET /metrics`

## Syllabus coverage – what is real and what is not
| CO | Topic | Where | Status |
|---|---|---|---|
| 1 | Schema, DDL, constraints, normalisation, indexes | `sql/schema.sql`, `app/models.py` | Built |
| 1 | ER model, mapping | `docs/ARCHITECTURE.md` | Documented |
| 1 | Joins, subqueries, CTEs, window functions | `sql/queries.sql`, `/admin/analytics/trips` | Built |
| 1 | Views, triggers, procedure, MVCC/isolation | `sql/schema.sql`, `sql/queries.sql` | Written; **not run against a live PostgreSQL by me** |
| 2 | MongoDB CRUD, aggregation, TTL index | `app/mongo.py`, `mongo/aggregations.js` | Built (in-memory fallback tested; live MongoDB not tested) |
| 2 | SQL + NoSQL integration, CAP | `docs/ARCHITECTURE.md`, `routers/student.py` | Built |
| 2 | pgvector, HNSW/IVF, hybrid search, RAG | `app/services.py`, `sql/schema.sql` | Built with a demo embedder; Pinecone/Weaviate **not** included |
| 3 | REST, OpenAPI, Pydantic, DI, middleware | all of `app/` (`/docs`) | Built |
| 3 | JWT, RBAC, hashing, rate limiting | `security.py`, `deps.py`, `middleware.py` | Built. Third-party OAuth2 login not included |
| 3 | SQLAlchemy, Motor, pytest, coverage; layered refactor | `tests/`, `app/` | Built (11 tests, 88%) |
| 3 | Flask & Django (self-learning) | – | **Not built** |
| 4 | Node/Express, Spring Boot, .NET | – | **Not built** (separate stacks) |
| 5 | Microservices, gateway, Saga/2PC | `docs/ARCHITECTURE.md` | **Design only**; this is one layered service |
| 6 | Docker, Compose, K8s, Prometheus/Grafana, OTel | `Dockerfile`, `docker-compose.yml`, `k8s/`, `monitoring/` | Written; **Docker/K8s not run by me** |
| 6 | CI/CD, image scan, load test, C4 docs | `.github/workflows/ci.yml`, `loadtest/` | Written |
