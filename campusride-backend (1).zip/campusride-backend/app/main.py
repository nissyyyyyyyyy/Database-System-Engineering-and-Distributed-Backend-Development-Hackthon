import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_fastapi_instrumentator import Instrumentator
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .bootstrap import init_db
from .config import settings
from .database import get_db
from .middleware import RateLimitMiddleware
from .mongo import store
from .routers import auth, fleet, student
from .services import DomainError

log = logging.getLogger("campusride")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    await store.start(settings.mongo_url, settings.mongo_db)
    yield
    await store.stop()


app = FastAPI(title="CampusRide API", version="1.0.0", lifespan=lifespan,
              description="Smart College Bus Management: PostgreSQL + MongoDB + pgvector, JWT/RBAC.")
app.add_middleware(RateLimitMiddleware, limit=settings.rate_limit_per_minute)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins.split(","),
                   allow_methods=["*"], allow_headers=["*"])
for r in (auth.router, fleet.router, student.router):
    app.include_router(r)

Instrumentator().instrument(app).expose(app, include_in_schema=False)   # Prometheus /metrics

if settings.otel_enabled:                                                # OpenTelemetry tracing (optional)
    try:
        from opentelemetry import trace
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
        provider = TracerProvider()
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
        trace.set_tracer_provider(provider)
        FastAPIInstrumentor.instrument_app(app)
    except ImportError:
        log.warning("OTEL_ENABLED set but OpenTelemetry packages are missing")


@app.exception_handler(DomainError)
async def _domain(_, exc: DomainError):
    return JSONResponse({"detail": exc.detail}, status_code=exc.status)


@app.exception_handler(IntegrityError)
async def _integrity(_, exc: IntegrityError):
    return JSONResponse({"detail": "Constraint violated: duplicate value or record still in use"}, status_code=409)


@app.get("/health", tags=["ops"])
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok", "sql": db.get_bind().dialect.name, "documents": store.backend}


# Serve the website from the same origin as the API (no CORS setup needed). Keep this LAST.
from pathlib import Path  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402

app.mount("/", StaticFiles(directory=Path(__file__).parent / "static", html=True), name="site")
