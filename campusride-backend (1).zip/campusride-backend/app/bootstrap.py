from sqlalchemy import func, select, text

from .config import settings
from .database import Base, SessionLocal, engine
from .models import Bus, Driver, Notice, User
from .schemas import BusIn, DriverIn, RouteIn, ScheduleIn, StopIn
from .security import hash_password
from . import services

ROUTES = {
    "North Line": [("Kukatpally", 0), ("Nizampet", 10), ("Quthbullapur", 18), ("Suchitra", 26), ("College Campus", 40)],
    "City Line": [("Secunderabad", 0), ("Paradise", 8), ("Begumpet", 16), ("Ameerpet", 26), ("College Campus", 45)],
    "East Line": [("Uppal", 0), ("Habsiguda", 9), ("Tarnaka", 17), ("Mettuguda", 25), ("College Campus", 38)],
}
DRIVERS = [("Ramesh Kumar", "9848011111"), ("Suresh Reddy", "9848022222"), ("Anita Rao", "9848033333"), ("Vijay Singh", "9848044444")]
BUSES = [("TS-08-1101", 50, "North Line", 0), ("TS-08-1102", 45, "City Line", 1), ("TS-08-1103", 50, "East Line", 2), ("TS-08-1104", 40, "North Line", 3)]
TRIPS = [(0, "07:15", "in"), (3, "08:00", "in"), (1, "07:20", "in"), (2, "07:30", "in"),
         (0, "16:15", "out"), (3, "17:00", "out"), (1, "16:30", "out"), (2, "16:45", "out")]
NOTICES = [("Extra buses during exam week", "Additional morning buses run on all routes during exam week. Expect fuller buses between 7 and 9 AM."),
           ("Holiday timetable", "On public holidays only the North Line runs, with a single morning and evening trip."),
           ("Monsoon safety advisory", "During heavy rain buses may run ten minutes late. Wait at covered stops and check live arrival times.")]


def init_db():
    if engine.dialect.name == "postgresql":
        with engine.begin() as c:
            c.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    Base.metadata.create_all(engine)       # no-op for tables already created by sql/schema.sql
    if settings.seed_demo_data:
        with SessionLocal() as db:
            seed(db)


def seed(db):
    if db.scalar(select(func.count()).select_from(User)):
        return
    db.add(User(email=settings.admin_email, full_name="Transport Admin", role="admin",
                password_hash=hash_password(settings.admin_password)))
    drivers = [services.create_driver(db, DriverIn(name=n, phone=p)) for n, p in DRIVERS]
    routes = {n: services.create_route(db, RouteIn(name=n, stops=[StopIn(name=s, minutes=m) for s, m in st]))
              for n, st in ROUTES.items()}
    buses = [services.create_bus(db, BusIn(number=num, capacity=cap, route_id=routes[r].id, driver_id=drivers[d].id))
             for num, cap, r, d in BUSES]
    for b, t, d in TRIPS:
        services.create_schedule(db, ScheduleIn(bus_id=buses[b].id, departure_time=t, direction=d))
    for title, body in NOTICES:
        services.add_notice(db, title, body)
