"""Service layer: business rules. Routers call services; services call repositories."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import repositories as repo
from .crowd import predict_crowd
from .embeddings import cosine, embed, tokens
from .models import Bus, Driver, Notice, Route, RouteStop, Schedule
from .schemas import BusIn, DriverIn, RouteIn, ScheduleIn


class DomainError(Exception):
    def __init__(self, status: int, detail: str):
        self.status, self.detail = status, detail


def hhmm(minutes: int) -> str:
    return f"{(minutes // 60) % 24:02d}:{minutes % 60:02d}"


# ---------- fleet ----------
def create_driver(db: Session, data: DriverIn) -> Driver:
    return repo.add(db, Driver(**data.model_dump()))


def create_route(db: Session, data: RouteIn) -> Route:
    if db.scalar(select(Route).where(Route.name == data.name)):
        raise DomainError(409, "Route name already exists")
    route = Route(name=data.name)
    for i, s in enumerate(data.stops):
        route.route_stops.append(RouteStop(stop=repo.get_or_create_stop(db, s.name), seq=i, minutes_from_start=s.minutes))
    db.add(route)
    db.commit()
    return route


def create_bus(db: Session, data: BusIn) -> Bus:
    if not db.get(Route, data.route_id):
        raise DomainError(404, "Route not found")
    if data.driver_id is not None and not db.get(Driver, data.driver_id):
        raise DomainError(404, "Driver not found")
    return repo.add(db, Bus(**data.model_dump()))


def create_schedule(db: Session, data: ScheduleIn) -> Schedule:
    if not db.get(Bus, data.bus_id):
        raise DomainError(404, "Bus not found")
    return repo.add(db, Schedule(**data.model_dump()))


def delete_entity(db: Session, model, entity_id: int):
    obj = db.get(model, entity_id)
    if not obj:
        raise DomainError(404, f"{model.__name__} not found")
    repo.remove(db, obj)


# ---------- timetable logic ----------
def trip_path(sc: Schedule) -> list[tuple[str, int]]:
    """(stop name, arrival minute-of-day) in travel order for one trip."""
    rs = sc.bus.route.route_stops
    dep = sc.departure_time.hour * 60 + sc.departure_time.minute
    total = rs[-1].minutes_from_start
    if sc.direction == "in":
        return [(r.stop.name, dep + r.minutes_from_start) for r in rs]
    return [(r.stop.name, dep + total - r.minutes_from_start) for r in reversed(rs)]


def _crowd(sc: Schedule, idx: int, n: int, weekday: int, exam: bool, fb: dict[int, float]) -> dict:
    dep = sc.departure_time.hour * 60 + sc.departure_time.minute
    return predict_crowd(dep, sc.direction, idx, n, sc.bus.capacity, weekday, exam, fb.get(sc.bus_id))


def arrivals(db: Session, stop: str, direction: str, now_min: int, weekday: int, exam: bool, fb: dict[int, float]):
    out = []
    for sc in repo.schedules_full(db, direction):
        path = trip_path(sc)
        idx = next((i for i, (n, _) in enumerate(path) if n == stop), None)
        if idx is None or path[idx][1] < now_min:
            continue
        at, c = path[idx][1], _crowd(sc, idx, len(path), weekday, exam, fb)
        d = sc.bus.driver
        out.append(dict(bus_id=sc.bus_id, bus_number=sc.bus.number, route=sc.bus.route.name, direction=sc.direction,
                        arrives_at=hhmm(at), minutes_away=at - now_min, driver=d.name if d else None,
                        driver_phone=d.phone if d else None, crowd_level=c["level"],
                        occupancy_pct=round(c["occupancy"] * 100), seats_free=c["seats_free"]))
    return sorted(out, key=lambda r: r["minutes_away"])


def live_status(db: Session, now_min: int, weekday: int, fb: dict[int, float]):
    out = []
    for sc in repo.schedules_full(db):
        path = trip_path(sc)
        start, end = path[0][1], path[-1][1]
        row = dict(bus_number=sc.bus.number, route=sc.bus.route.name, direction=sc.direction,
                   departs=hhmm(start), ends=hhmm(end), status="scheduled", next_stop=None, crowd_level=None)
        if now_min > end:
            row["status"] = "finished"
        elif now_min >= start:
            idx = next(i for i, (_, t) in enumerate(path) if t >= now_min)
            row.update(status="running", next_stop=path[idx][0],
                       crowd_level=_crowd(sc, idx, len(path), weekday, False, fb)["level"])
        out.append(row)
    return out


# ---------- notices: vector + keyword (hybrid) search ----------
def add_notice(db: Session, title: str, body: str) -> Notice:
    return repo.add(db, Notice(title=title, body=body, embedding=embed(f"{title} {body}")))


def search_notices(db: Session, q: str, mode: str = "hybrid", k: int = 5) -> list[dict]:
    qv, qt = embed(q), set(tokens(q))

    def kw(n: Notice) -> float:
        return len(qt & set(tokens(f"{n.title} {n.body}"))) / len(qt) if qt else 0.0

    if mode == "keyword":
        cands = [(n, 0.0) for n in repo.list_all(db, Notice, 1000)]
    elif db.get_bind().dialect.name == "postgresql":   # pgvector ANN (HNSW index) then re-rank
        dist = Notice.embedding.cosine_distance(qv)
        cands = [(n, 1 - float(d)) for n, d in db.execute(select(Notice, dist).order_by(dist).limit(50)).all()]
    else:                                              # SQLite (tests): brute-force cosine
        cands = [(n, cosine(qv, n.embedding)) for n in repo.list_all(db, Notice, 1000)]
    wv, wk = {"vector": (1, 0), "keyword": (0, 1), "hybrid": (0.6, 0.4)}[mode]
    scored = sorted(((wv * v + wk * kw(n), n) for n, v in cands), key=lambda x: -x[0])
    return [dict(id=n.id, title=n.title, body=n.body, score=round(s, 4)) for s, n in scored[:k] if s > 0]


def answer_question(db: Session, q: str) -> dict:
    """RAG-lite: retrieve top notices, answer extractively. Plug an LLM in at `answer` for generation."""
    hits = search_notices(db, q, "hybrid", 3)
    return dict(question=q, answer=hits[0]["body"] if hits else "No matching notice found.", sources=hits)
