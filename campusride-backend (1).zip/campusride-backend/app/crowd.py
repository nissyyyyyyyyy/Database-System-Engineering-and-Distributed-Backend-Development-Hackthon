"""Crowd-level predictor (the project's Python component). Same logic as the website."""
import math

DAY_ADJ = [0, 0.05, 0.03, 0, 0, -0.08, -0.25]  # Monday..Sunday


def predict_crowd(departure_min: int, direction: str, stop_index: int, n_stops: int, capacity: int,
                  weekday: int, exam_day: bool = False, feedback_avg: float | None = None) -> dict:
    frac = stop_index / (n_stops - 1) if n_stops > 1 else 0.0
    peak = 480 if direction == "in" else 1000                 # 08:00 inbound, 16:40 outbound
    occ = 0.25 + 0.55 * math.exp(-(((departure_min - peak) / 70) ** 2))
    occ *= (0.55 + 0.6 * frac) if direction == "in" else (1.15 - 0.6 * frac)
    occ += DAY_ADJ[weekday]
    if weekday >= 5:
        occ *= 0.5
    if exam_day:
        occ += 0.12
    if feedback_avg is not None:                               # student reports: 0 empty .. 1 packed
        occ += (feedback_avg - 0.5) * 0.3
    occ = min(1.0, max(0.04, occ))
    level = "Low" if occ < 0.45 else "Medium" if occ < 0.75 else "High"
    return {"occupancy": occ, "level": level, "seats_free": max(0, round(capacity * (1 - occ)))}
