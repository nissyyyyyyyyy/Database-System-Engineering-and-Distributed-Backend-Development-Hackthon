"""Tiny deterministic text embedder (hashing trick, 64 dims, L2-normalised).
Swap `embed` for a real model (e.g. sentence-transformers) without changing callers."""
import hashlib
import math
import re

from .models import EMBED_DIM

_STOP = {"the", "a", "an", "is", "to", "of", "and", "in", "on", "for", "at", "are", "be", "by", "will"}


def tokens(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP]


def embed(text: str) -> list[float]:
    v = [0.0] * EMBED_DIM
    for w in tokens(text):
        h = int(hashlib.md5(w.encode()).hexdigest(), 16)
        v[h % EMBED_DIM] += 1.0 if (h >> 8) & 1 else -1.0
    norm = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / norm for x in v]


def cosine(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))
