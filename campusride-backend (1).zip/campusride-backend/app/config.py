from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./campusride.db"   # postgresql+psycopg2://user:pw@host/db in Docker
    mongo_url: str | None = None                      # unset -> in-memory fallback for crowd reports
    mongo_db: str = "campusride"
    jwt_secret: str = "dev-secret-change-me"
    jwt_expire_minutes: int = 60
    rate_limit_per_minute: int = 120
    seed_demo_data: bool = True
    admin_email: str = "admin@campus.edu"
    admin_password: str = "admin12345"
    cors_origins: str = "*"
    timezone: str = "Asia/Kolkata"
    otel_enabled: bool = False


settings = Settings()
