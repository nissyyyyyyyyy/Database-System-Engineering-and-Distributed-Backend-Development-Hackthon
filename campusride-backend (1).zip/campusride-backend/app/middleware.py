import time
from collections import defaultdict, deque

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Sliding-window limiter per client IP (single-process; use Redis for multi-replica deployments)."""

    def __init__(self, app, limit: int = 120, window: int = 60):
        super().__init__(app)
        self.limit, self.window = limit, window
        self.hits: dict[str, deque] = defaultdict(deque)

    async def dispatch(self, request, call_next):
        if request.url.path in ("/health", "/metrics"):
            return await call_next(request)
        ip = request.client.host if request.client else "unknown"
        now, q = time.monotonic(), self.hits[ip]
        while q and now - q[0] > self.window:
            q.popleft()
        if len(q) >= self.limit:
            return JSONResponse({"detail": "Rate limit exceeded"}, status_code=429,
                                headers={"Retry-After": str(self.window)})
        q.append(now)
        return await call_next(request)
