"""Repository layer: the only place that talks to SQLAlchemy queries."""
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from .models import Bus, Route, RouteStop, Schedule, Stop, User


def list_all(db: Session, model, limit: int = 100, offset: int = 0):
    return db.scalars(select(model).order_by(model.id).limit(limit).offset(offset)).all()


def add(db: Session, obj):
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


def remove(db: Session, obj):
    db.delete(obj)
    db.commit()


def user_by_email(db: Session, email: str) -> User | None:
    return db.scalar(select(User).where(User.email == email.lower()))


def get_or_create_stop(db: Session, name: str) -> Stop:
    stop = db.scalar(select(Stop).where(Stop.name == name))
    if not stop:
        stop = Stop(name=name)
        db.add(stop)
        db.flush()
    return stop


def routes_full(db: Session):
    q = select(Route).options(selectinload(Route.route_stops).selectinload(RouteStop.stop)).order_by(Route.id)
    return db.scalars(q).all()


def schedules_full(db: Session, direction: str | None = None):
    q = select(Schedule).options(
        selectinload(Schedule.bus).selectinload(Bus.route).selectinload(Route.route_stops).selectinload(RouteStop.stop),
        selectinload(Schedule.bus).selectinload(Bus.driver))
    if direction:
        q = q.where(Schedule.direction == direction)
    return db.scalars(q.order_by(Schedule.departure_time)).all()


def stop_names(db: Session) -> list[str]:
    return list(db.scalars(select(Stop.name).order_by(Stop.name)).all())
