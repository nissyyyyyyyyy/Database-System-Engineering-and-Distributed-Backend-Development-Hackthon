"""ORM models. Mirrors sql/schema.sql (3NF; route_stops resolves the Route<->Stop M:N)."""
from datetime import datetime, time

from pgvector.sqlalchemy import Vector
from sqlalchemy import (JSON, CheckConstraint, DateTime, ForeignKey, String, Text, Time,
                        UniqueConstraint, func)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base

EMBED_DIM = 64


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    full_name: Mapped[str] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(10), default="student")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (CheckConstraint("role in ('admin','driver','student')", name="ck_users_role"),)


class Driver(Base):
    __tablename__ = "drivers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    phone: Mapped[str] = mapped_column(String(20), unique=True)


class Stop(Base):
    __tablename__ = "stops"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)


class Route(Base):
    __tablename__ = "routes"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    route_stops: Mapped[list["RouteStop"]] = relationship(
        back_populates="route", order_by="RouteStop.seq", cascade="all, delete-orphan")


class RouteStop(Base):
    __tablename__ = "route_stops"
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id", ondelete="CASCADE"), primary_key=True)
    stop_id: Mapped[int] = mapped_column(ForeignKey("stops.id", ondelete="RESTRICT"), primary_key=True)
    seq: Mapped[int]
    minutes_from_start: Mapped[int]
    route: Mapped["Route"] = relationship(back_populates="route_stops")
    stop: Mapped["Stop"] = relationship()
    __table_args__ = (UniqueConstraint("route_id", "seq", name="uq_route_seq"),
                      CheckConstraint("minutes_from_start >= 0", name="ck_minutes"))


class Bus(Base):
    __tablename__ = "buses"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(20), unique=True)
    capacity: Mapped[int]
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id", ondelete="RESTRICT"))
    driver_id: Mapped[int | None] = mapped_column(ForeignKey("drivers.id", ondelete="SET NULL"), unique=True)
    route: Mapped["Route"] = relationship()
    driver: Mapped["Driver | None"] = relationship()
    schedules: Mapped[list["Schedule"]] = relationship(back_populates="bus", cascade="all, delete-orphan")
    __table_args__ = (CheckConstraint("capacity > 0", name="ck_capacity"),)


class Schedule(Base):
    __tablename__ = "schedules"
    id: Mapped[int] = mapped_column(primary_key=True)
    bus_id: Mapped[int] = mapped_column(ForeignKey("buses.id", ondelete="CASCADE"))
    departure_time: Mapped[time] = mapped_column(Time)
    direction: Mapped[str] = mapped_column(String(3))
    bus: Mapped["Bus"] = relationship(back_populates="schedules")
    __table_args__ = (UniqueConstraint("bus_id", "departure_time", "direction", name="uq_trip"),
                      CheckConstraint("direction in ('in','out')", name="ck_direction"))


class Notice(Base):
    __tablename__ = "notices"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(150))
    body: Mapped[str] = mapped_column(Text)
    embedding: Mapped[list[float]] = mapped_column(Vector(EMBED_DIM).with_variant(JSON(), "sqlite"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
