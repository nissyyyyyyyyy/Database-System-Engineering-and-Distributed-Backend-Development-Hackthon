from datetime import time
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

EMAIL = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
ORM = ConfigDict(from_attributes=True)


class RegisterIn(BaseModel):
    email: str = Field(pattern=EMAIL, max_length=255)
    full_name: str = Field(min_length=2, max_length=120)
    password: str = Field(min_length=8, max_length=72)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ORM
    id: int
    email: str
    full_name: str
    role: str


class RoleIn(BaseModel):
    role: Literal["admin", "driver", "student"]


class DriverIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    phone: str = Field(min_length=7, max_length=20)


class DriverOut(DriverIn):
    model_config = ORM
    id: int


class StopIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    minutes: int = Field(ge=0, le=600, description="Minutes after the first stop")


class RouteIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    stops: list[StopIn] = Field(min_length=2, description="In travel order; the last stop is the campus")

    @model_validator(mode="after")
    def _check(self):
        names = [s.name.lower() for s in self.stops]
        if len(set(names)) != len(names):
            raise ValueError("duplicate stop in route")
        mins = [s.minutes for s in self.stops]
        if mins != sorted(mins):
            raise ValueError("stop minutes must not decrease")
        return self


class RouteOut(BaseModel):
    id: int
    name: str
    stops: list[StopIn]


class BusIn(BaseModel):
    number: str = Field(min_length=3, max_length=20)
    capacity: int = Field(ge=1, le=120)
    route_id: int
    driver_id: int | None = None


class BusOut(BusIn):
    model_config = ORM
    id: int


class ScheduleIn(BaseModel):
    bus_id: int
    departure_time: time
    direction: Literal["in", "out"] = Field(description="in = to campus, out = back home")


class ScheduleOut(ScheduleIn):
    model_config = ORM
    id: int


class ReportIn(BaseModel):
    bus_id: int
    level: Literal["empty", "ok", "packed"]


class NoticeIn(BaseModel):
    title: str = Field(min_length=3, max_length=150)
    body: str = Field(min_length=5, max_length=2000)


class NoticeHit(BaseModel):
    id: int
    title: str
    body: str
    score: float


class RagOut(BaseModel):
    question: str
    answer: str
    sources: list[NoticeHit]


class ArrivalOut(BaseModel):
    bus_id: int
    bus_number: str
    route: str
    direction: str
    arrives_at: str
    minutes_away: int
    driver: str | None
    driver_phone: str | None
    crowd_level: Literal["Low", "Medium", "High"]
    occupancy_pct: int
    seats_free: int
