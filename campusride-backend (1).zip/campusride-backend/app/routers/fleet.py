from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy import text
from sqlalchemy.orm import Session

from .. import repositories as repo
from .. import services
from ..database import get_db
from ..deps import admin_only, current_user
from ..models import Bus, Driver, Route, Schedule
from ..schemas import (BusIn, BusOut, DriverIn, DriverOut, RouteIn, RouteOut, ScheduleIn, ScheduleOut, StopIn)

router = APIRouter(tags=["fleet"], dependencies=[Depends(current_user)])  # reads: any logged-in user
Page = dict(limit=Query(100, ge=1, le=500), offset=Query(0, ge=0))


def route_out(r: Route) -> RouteOut:
    return RouteOut(id=r.id, name=r.name, stops=[StopIn(name=x.stop.name, minutes=x.minutes_from_start) for x in r.route_stops])


# ---- drivers
@router.get("/drivers", response_model=list[DriverOut])
def list_drivers(db: Session = Depends(get_db), limit: int = Page["limit"], offset: int = Page["offset"]):
    return repo.list_all(db, Driver, limit, offset)


@router.post("/drivers", response_model=DriverOut, status_code=201, dependencies=[Depends(admin_only)])
def add_driver(data: DriverIn, db: Session = Depends(get_db)):
    return services.create_driver(db, data)


@router.delete("/drivers/{id}", status_code=204, dependencies=[Depends(admin_only)])
def del_driver(id: int, db: Session = Depends(get_db)):
    services.delete_entity(db, Driver, id)
    return Response(status_code=204)


# ---- routes & stops
@router.get("/routes", response_model=list[RouteOut])
def list_routes(db: Session = Depends(get_db)):
    return [route_out(r) for r in repo.routes_full(db)]


@router.post("/routes", response_model=RouteOut, status_code=201, dependencies=[Depends(admin_only)])
def add_route(data: RouteIn, db: Session = Depends(get_db)):
    return route_out(services.create_route(db, data))


@router.delete("/routes/{id}", status_code=204, dependencies=[Depends(admin_only)])
def del_route(id: int, db: Session = Depends(get_db)):
    services.delete_entity(db, Route, id)
    return Response(status_code=204)


# ---- buses
@router.get("/buses", response_model=list[BusOut])
def list_buses(db: Session = Depends(get_db), limit: int = Page["limit"], offset: int = Page["offset"]):
    return repo.list_all(db, Bus, limit, offset)


@router.post("/buses", response_model=BusOut, status_code=201, dependencies=[Depends(admin_only)])
def add_bus(data: BusIn, db: Session = Depends(get_db)):
    return services.create_bus(db, data)


@router.delete("/buses/{id}", status_code=204, dependencies=[Depends(admin_only)])
def del_bus(id: int, db: Session = Depends(get_db)):
    services.delete_entity(db, Bus, id)
    return Response(status_code=204)


# ---- schedules
@router.get("/schedules", response_model=list[ScheduleOut])
def list_schedules(db: Session = Depends(get_db), limit: int = Page["limit"], offset: int = Page["offset"]):
    return repo.list_all(db, Schedule, limit, offset)


@router.post("/schedules", response_model=ScheduleOut, status_code=201, dependencies=[Depends(admin_only)])
def add_schedule(data: ScheduleIn, db: Session = Depends(get_db)):
    return services.create_schedule(db, data)


@router.delete("/schedules/{id}", status_code=204, dependencies=[Depends(admin_only)])
def del_schedule(id: int, db: Session = Depends(get_db)):
    services.delete_entity(db, Schedule, id)
    return Response(status_code=204)


# ---- admin analytics (CTE + window functions; runs on PostgreSQL and SQLite)
TRIPS_SQL = text("""
WITH trip_counts AS (SELECT bus_id, COUNT(*) AS trips FROM schedules GROUP BY bus_id)
SELECT b.number AS bus, r.name AS route, t.trips,
       RANK() OVER (ORDER BY t.trips DESC) AS rank,
       SUM(t.trips) OVER () AS total_trips
FROM trip_counts t JOIN buses b ON b.id = t.bus_id JOIN routes r ON r.id = b.route_id
ORDER BY rank, b.number""")


@router.get("/admin/analytics/trips", dependencies=[Depends(admin_only)], tags=["admin"])
def trips_per_bus(db: Session = Depends(get_db)):
    return [dict(r) for r in db.execute(TRIPS_SQL).mappings()]


@router.get("/admin/audit", dependencies=[Depends(admin_only)], tags=["admin"],
            summary="Rows written by the PostgreSQL audit trigger (see sql/schema.sql)")
def audit(db: Session = Depends(get_db)):
    try:
        rows = db.execute(text("SELECT id, table_name, action, row_id, changed_at FROM audit_log "
                               "ORDER BY id DESC LIMIT 50")).mappings().all()
        return [dict(r) for r in rows]
    except Exception:  # table only exists on PostgreSQL
        db.rollback()
        return []
