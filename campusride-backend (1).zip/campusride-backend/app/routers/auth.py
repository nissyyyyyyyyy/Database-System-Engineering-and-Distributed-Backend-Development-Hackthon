from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from .. import repositories as repo
from ..database import get_db
from ..deps import admin_only, current_user
from ..models import User
from ..schemas import RegisterIn, RoleIn, TokenOut, UserOut
from ..security import create_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=UserOut, status_code=201, summary="Student self-registration")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if repo.user_by_email(db, data.email):
        raise HTTPException(409, "Email already registered")
    return repo.add(db, User(email=data.email.lower(), full_name=data.full_name,
                             password_hash=hash_password(data.password), role="student"))


@router.post("/login", response_model=TokenOut, summary="OAuth2 password flow -> JWT")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = repo.user_by_email(db, form.username)
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Wrong email or password", headers={"WWW-Authenticate": "Bearer"})
    return TokenOut(access_token=create_token(user.id, user.role))


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@router.patch("/users/{user_id}/role", response_model=UserOut, dependencies=[Depends(admin_only)])
def set_role(user_id: int, data: RoleIn, db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(404, "User not found")
    user.role = data.role
    db.commit()
    return user
