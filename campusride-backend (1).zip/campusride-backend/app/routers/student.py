from datetime import date, datetime, time
from typing import Literal
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from .. import repositories as repo
from .. import services
from ..config import settings
from ..database import get_db
from ..deps import admin_only, current_user
from ..models import Bus, User
from ..mongo import store
from ..schemas import ArrivalOut, NoticeHit, NoticeIn, RagOut, ReportIn

router = APIRouter(prefix="/student", tags=["student"], dependencies=[Depends(current_user)])


def _now() -> datetime:
    return datetime.now(ZoneInfo(settings.timezone))


@router.get("/stops", response_model=list[str])
def stops(db: Session = Depends(get_db)):
    return repo.stop_names(db)


@router.get("/arrivals", response_model=list[ArrivalOut], summary="Upcoming buses at a stop with predicted crowd")
async def arrivals(stop: str, direction: Literal["in", "out"] = "in", at: time | None = None,
                   weekday: int | None = Query(None, ge=0, le=6, description="0=Mon"), exam: bool = False,
                   db: Session = Depends(get_db)):
    now = _now()
    now_min = at.hour * 60 + at.minute if at else now.hour * 60 + now.minute
    fb = await store.averages()          # eventually-consistent crowd signal from MongoDB
    return services.arrivals(db, stop, direction, now_min, now.weekday() if weekday is None else weekday, exam, fb)


@router.get("/live", summary="Where each bus is right now")
async def live(db: Session = Depends(get_db)):
    now = _now()
    return services.live_status(db, now.hour * 60 + now.minute, now.weekday(), await store.averages())


@router.post("/reports", status_code=201, summary="Report how crowded a bus is")
async def report(data: ReportIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not db.get(Bus, data.bus_id):     # referential check against the relational source of truth
        raise HTTPException(404, "Bus not found")
    await store.add(data.bus_id, data.level, user.id)
    return {"ok": True, "stored_in": store.backend}


@router.get("/notices/search", response_model=list[NoticeHit], summary="Keyword / vector / hybrid search")
def search(q: str = Query(min_length=2), mode: Literal["hybrid", "vector", "keyword"] = "hybrid",
           db: Session = Depends(get_db)):
    return services.search_notices(db, q, mode)


@router.get("/notices/ask", response_model=RagOut, summary="Ask a question; answered from notices (RAG-lite)")
def ask(q: str = Query(min_length=3), db: Session = Depends(get_db)):
    return services.answer_question(db, q)


@router.post("/notices", status_code=201, dependencies=[Depends(admin_only)], summary="Publish a notice (admin)")
def add_notice(data: NoticeIn, db: Session = Depends(get_db)):
    n = services.add_notice(db, data.title, data.body)
    return {"id": n.id, "title": n.title}
