"""Document store for high-volume, short-lived crowd reports (MongoDB via Motor).
Falls back to an in-memory list when MONGO_URL is not set or unreachable."""
import logging
from datetime import datetime, timedelta, timezone

log = logging.getLogger("campusride.mongo")
LEVELS = {"empty": 0.0, "ok": 0.5, "packed": 1.0}


class ReportStore:
    def __init__(self):
        self._client = None
        self._col = None
        self._mem: list[dict] = []

    @property
    def backend(self) -> str:
        return "mongodb" if self._col is not None else "memory"

    async def start(self, url: str | None, dbname: str):
        if not url:
            return
        try:
            from motor.motor_asyncio import AsyncIOMotorClient
            self._client = AsyncIOMotorClient(url, serverSelectionTimeoutMS=3000)
            col = self._client[dbname]["crowd_reports"]
            await col.create_index([("bus_id", 1), ("ts", -1)])          # query index
            await col.create_index("ts", expireAfterSeconds=24 * 3600)   # TTL: reports expire after a day
            self._col = col
        except Exception as exc:  # noqa: BLE001
            log.warning("MongoDB unavailable (%s); using in-memory store", exc)
            self._col = None

    async def stop(self):
        if self._client:
            self._client.close()

    async def add(self, bus_id: int, level: str, user_id: int):
        doc = {"bus_id": bus_id, "level": LEVELS[level], "user_id": user_id, "ts": datetime.now(timezone.utc)}
        if self._col is not None:
            await self._col.insert_one(doc)
        else:
            self._mem.append(doc)

    async def averages(self, minutes: int = 30) -> dict[int, float]:
        """Average reported crowd level per bus over the last N minutes (aggregation pipeline)."""
        since = datetime.now(timezone.utc) - timedelta(minutes=minutes)
        out: dict[int, float] = {}
        if self._col is not None:
            pipeline = [{"$match": {"ts": {"$gte": since}}},
                        {"$group": {"_id": "$bus_id", "avg": {"$avg": "$level"}, "n": {"$sum": 1}}}]
            async for r in self._col.aggregate(pipeline):
                out[r["_id"]] = r["avg"]
        else:
            acc: dict[int, list[float]] = {}
            for d in self._mem:
                if d["ts"] >= since:
                    acc.setdefault(d["bus_id"], []).append(d["level"])
            out = {k: sum(v) / len(v) for k, v in acc.items()}
        return out


store = ReportStore()
