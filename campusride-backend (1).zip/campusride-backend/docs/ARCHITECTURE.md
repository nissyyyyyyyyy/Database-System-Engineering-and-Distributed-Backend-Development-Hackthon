# CampusRide – Architecture (CO1, CO2, CO5, CO6 documentation)

## ER model (CO1)
```mermaid
erDiagram
  ROUTES ||--o{ ROUTE_STOPS : "has"
  STOPS  ||--o{ ROUTE_STOPS : "appears in"
  ROUTES ||--o{ BUSES : "served by"
  DRIVERS |o--o| BUSES : "drives (max 1 bus)"
  BUSES  ||--o{ SCHEDULES : "runs"
  USERS { int id PK  string email UK  string role }
  ROUTE_STOPS { int route_id PK,FK  int stop_id PK,FK  int seq  int minutes_from_start }
  BUSES { int id PK  string number UK  int capacity  int route_id FK  int driver_id FK_UK }
  SCHEDULES { int id PK  int bus_id FK  time departure_time  string direction }
  NOTICES { int id PK  string title  text body  vector embedding }
```
**Mapping notes:** Route–Stop is M:N, so it becomes the associative table `route_stops` (its own attributes: `seq`, `minutes_from_start`). Driver–Bus is 1:0..1, enforced with `UNIQUE(driver_id)`.

**Normalisation:** 1NF – atomic columns, no stop lists inside a route row. 2NF – in `route_stops`, `seq`/`minutes` depend on the whole key (route, stop). 3NF – stop names live once in `stops`; driver phone lives only in `drivers`; no transitive dependencies.

## Containers (CO6 – C4 level 2)
```mermaid
flowchart LR
  Web["Student web app (HTML/JS)"] -->|HTTPS + JWT| API["FastAPI service<br/>routers → services → repositories"]
  API -->|SQLAlchemy| PG[("PostgreSQL + pgvector<br/>fleet, users, notices")]
  API -->|Motor| MG[("MongoDB<br/>crowd reports (TTL)")]
  API -->|/metrics| PR["Prometheus"] --> GR["Grafana"]
```

## Polyglot persistence & consistency (CO2)
| Data | Store | Why | Consistency |
|---|---|---|---|
| Buses, routes, stops, drivers, schedules, users | PostgreSQL | relational integrity, constraints, joins | Strong (ACID) |
| Crowd reports | MongoDB | high write volume, schema-flexible, TTL expiry | Eventual; used only as a soft signal |
| Notice embeddings | PostgreSQL + pgvector | one transactional store; HNSW ANN index | Strong |

In CAP terms the relational side is CP (a partition means refusing writes, not diverging) and the report store is AP-leaning. **Dual-write rule:** the API checks the bus exists in PostgreSQL *before* writing to MongoDB. The only cross-store reference is `bus_id`; a stale report for a deleted bus is harmless and expires by TTL.

**Hybrid search / RAG:** `GET /student/notices/search` retrieves candidates by vector distance (pgvector, HNSW) and re-ranks with a keyword score (0.6 vector + 0.4 keyword). `/student/notices/ask` returns the best notice as the answer and lists sources. Embeddings are a hashing-trick demo; swap `app/embeddings.py` for a real model.

## Layered architecture (CO3 refactoring)
`routers/` (HTTP, validation, auth) → `services.py` (rules) → `repositories.py` (queries) → `models.py`. Routers never build queries; repositories never raise HTTP errors.

## Security (CO3 / CO6 OWASP)
bcrypt password hashes · JWT (HS256, 60 min) · RBAC (`admin`, `driver`, `student`) via `require_roles` · per-IP rate limit (429) · Pydantic validation on every body · parameterised SQL only · CORS configurable · non-root container · `pip-audit` + Trivy in CI. Public self-registration always creates `student`; only an admin can change roles.
Open items: JWT refresh/revocation, HTTPS termination at ingress, Redis-backed rate limit for multiple replicas.

## Distributed design (CO5 – design only, not built)
Natural service boundaries: **Auth**, **Fleet** (PostgreSQL), **Crowd** (MongoDB), **Search** (pgvector), behind a gateway that forwards the JWT. Each would own its database (DB-per-service). Cross-service operation example – *"add bus with schedule"* as a **Saga**: (1) Fleet creates the bus → (2) Fleet creates the schedule → on failure run the compensating action *delete bus*. 2PC is avoided because the Mongo and Postgres operations are independent and compensatable.

## Observability & delivery (CO6)
`/metrics` (Prometheus) → Grafana at :3000 (add a dashboard on `http_request_duration_seconds`, `http_requests_total`). OpenTelemetry tracing is enabled with `OTEL_ENABLED=true`. CI: tests with coverage gate → dependency audit → image build + Trivy scan. Load test: `locust -f loadtest/locustfile.py`.
