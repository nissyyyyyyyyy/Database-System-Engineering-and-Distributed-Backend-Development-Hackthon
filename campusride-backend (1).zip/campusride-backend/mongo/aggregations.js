// CO2 MongoDB: run with  mongosh campusride mongo/aggregations.js
// Collection: crowd_reports { bus_id, level (0|0.5|1), user_id, ts }  -- created by the API; shown here for study.
db.crowd_reports.createIndex({ bus_id: 1, ts: -1 });
db.crowd_reports.createIndex({ ts: 1 }, { expireAfterSeconds: 86400 });   // TTL index

db.crowd_reports.insertMany([
  { bus_id: 1, level: 1.0, user_id: 7, ts: new Date() },
  { bus_id: 1, level: 0.5, user_id: 8, ts: new Date() },
  { bus_id: 2, level: 0.0, user_id: 9, ts: new Date() }
]);

// 1) Average crowd per bus, last 30 min (the pipeline the API uses)
db.crowd_reports.aggregate([
  { $match: { ts: { $gte: new Date(Date.now() - 30 * 60 * 1000) } } },
  { $group: { _id: "$bus_id", avg: { $avg: "$level" }, n: { $sum: 1 } } },
  { $sort: { avg: -1 } }
]);

// 2) Hourly trend per bus
db.crowd_reports.aggregate([
  { $group: { _id: { bus: "$bus_id", hour: { $dateTrunc: { date: "$ts", unit: "hour" } } }, avg: { $avg: "$level" } } },
  { $sort: { "_id.hour": 1 } }
]);

// 3) $facet: counts by level and busiest buses in one round trip
db.crowd_reports.aggregate([{ $facet: {
  byLevel: [{ $group: { _id: "$level", n: { $sum: 1 } } }],
  topBuses: [{ $group: { _id: "$bus_id", n: { $sum: 1 } } }, { $sort: { n: -1 } }, { $limit: 3 }]
}}]);
