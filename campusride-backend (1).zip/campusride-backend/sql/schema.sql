-- CampusRide PostgreSQL schema (CO1: DDL, constraints, normalisation, indexes, views, triggers, procedures; CO2: pgvector)
-- Loaded automatically by docker-compose (docker-entrypoint-initdb.d).
CREATE EXTENSION IF NOT EXISTS vector;

-- ---------- Tables (3NF) ----------
CREATE TABLE users (
  id            SERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  full_name     VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(10)  NOT NULL DEFAULT 'student' CONSTRAINT ck_users_role CHECK (role IN ('admin','driver','student')),
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE TABLE drivers (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(120) NOT NULL,
  phone VARCHAR(20)  NOT NULL UNIQUE
);
CREATE TABLE stops  (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE);
CREATE TABLE routes (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE);

-- Route <-> Stop is many-to-many: resolved with an associative table that carries its own attributes.
CREATE TABLE route_stops (
  route_id           INT NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
  stop_id            INT NOT NULL REFERENCES stops(id)  ON DELETE RESTRICT,
  seq                INT NOT NULL,
  minutes_from_start INT NOT NULL CONSTRAINT ck_minutes CHECK (minutes_from_start >= 0),
  PRIMARY KEY (route_id, stop_id),
  CONSTRAINT uq_route_seq UNIQUE (route_id, seq)
);
CREATE TABLE buses (
  id        SERIAL PRIMARY KEY,
  number    VARCHAR(20) NOT NULL UNIQUE,
  capacity  INT NOT NULL CONSTRAINT ck_capacity CHECK (capacity > 0),
  route_id  INT NOT NULL REFERENCES routes(id)  ON DELETE RESTRICT,
  driver_id INT UNIQUE REFERENCES drivers(id) ON DELETE SET NULL      -- 1 driver : at most 1 bus
);
CREATE TABLE schedules (
  id             SERIAL PRIMARY KEY,
  bus_id         INT  NOT NULL REFERENCES buses(id) ON DELETE CASCADE,
  departure_time TIME NOT NULL,
  direction      VARCHAR(3) NOT NULL CONSTRAINT ck_direction CHECK (direction IN ('in','out')),
  CONSTRAINT uq_trip UNIQUE (bus_id, departure_time, direction)
);
-- Vector column for semantic search over notices (CO2 vector databases)
CREATE TABLE notices (
  id         SERIAL PRIMARY KEY,
  title      VARCHAR(150) NOT NULL,
  body       TEXT NOT NULL,
  embedding  vector(64) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Indexes ----------
CREATE INDEX idx_buses_route       ON buses(route_id);                    -- FK lookups / joins
CREATE INDEX idx_sched_bus_time    ON schedules(bus_id, departure_time);  -- timetable scans
CREATE INDEX idx_notices_hnsw      ON notices USING hnsw (embedding vector_cosine_ops);  -- ANN (graph based)
-- IVF alternative:  CREATE INDEX ON notices USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX idx_notices_fts       ON notices USING gin (to_tsvector('english', title || ' ' || body));  -- keyword half of hybrid search

-- ---------- View ----------
CREATE VIEW v_timetable AS
SELECT s.id AS schedule_id, s.departure_time, s.direction, b.number AS bus, b.capacity,
       r.name AS route, d.name AS driver, d.phone
FROM schedules s
JOIN buses  b ON b.id = s.bus_id
JOIN routes r ON r.id = b.route_id
LEFT JOIN drivers d ON d.id = b.driver_id;

-- ---------- Trigger: audit trail ----------
CREATE TABLE audit_log (
  id         SERIAL PRIMARY KEY,
  table_name TEXT NOT NULL,
  action     TEXT NOT NULL,
  row_id     INT,
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE OR REPLACE FUNCTION fn_audit() RETURNS trigger AS $$
DECLARE rid INT;
BEGIN
  IF TG_OP = 'DELETE' THEN rid := OLD.id; ELSE rid := NEW.id; END IF;
  INSERT INTO audit_log(table_name, action, row_id) VALUES (TG_TABLE_NAME, TG_OP, rid);
  RETURN NULL;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_audit_buses     AFTER INSERT OR UPDATE OR DELETE ON buses     FOR EACH ROW EXECUTE FUNCTION fn_audit();
CREATE TRIGGER trg_audit_schedules AFTER INSERT OR UPDATE OR DELETE ON schedules FOR EACH ROW EXECUTE FUNCTION fn_audit();
CREATE TRIGGER trg_audit_routes    AFTER INSERT OR UPDATE OR DELETE ON routes    FOR EACH ROW EXECUTE FUNCTION fn_audit();

-- ---------- Stored procedure ----------
CREATE OR REPLACE PROCEDURE assign_driver(p_bus INT, p_driver INT) LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM buses WHERE driver_id = p_driver AND id <> p_bus) THEN
    RAISE EXCEPTION 'Driver % already drives another bus', p_driver;
  END IF;
  UPDATE buses SET driver_id = p_driver WHERE id = p_bus;
END $$;
-- usage:  CALL assign_driver(1, 3);
