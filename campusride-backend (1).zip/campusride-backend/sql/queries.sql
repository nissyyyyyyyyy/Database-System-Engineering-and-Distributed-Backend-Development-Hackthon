-- CO1 SQL cookbook for CampusRide. Run in psql:  \i sql/queries.sql

-- Catalog tools (DBMS architecture / data independence)
-- \dt   \d buses   \di   \dv
SELECT table_name, column_name, data_type FROM information_schema.columns WHERE table_schema='public' ORDER BY 1, ordinal_position;
SELECT indexname, indexdef FROM pg_indexes WHERE schemaname='public';

-- Joins: full timetable (INNER + LEFT)
SELECT * FROM v_timetable ORDER BY departure_time;

-- Subquery: buses on routes that have more than 4 stops
SELECT number FROM buses WHERE route_id IN (SELECT route_id FROM route_stops GROUP BY route_id HAVING COUNT(*) > 4);

-- Aggregates + HAVING: seats offered per route
SELECT r.name, COUNT(b.id) AS buses, SUM(b.capacity) AS seats
FROM routes r LEFT JOIN buses b ON b.route_id = r.id GROUP BY r.name HAVING SUM(b.capacity) > 0;

-- CTE + window functions: rank buses by trips and show share of all trips
WITH trip_counts AS (SELECT bus_id, COUNT(*) AS trips FROM schedules GROUP BY bus_id)
SELECT b.number, t.trips,
       RANK() OVER (ORDER BY t.trips DESC)             AS rnk,
       ROUND(100.0 * t.trips / SUM(t.trips) OVER (), 1) AS pct_of_all_trips
FROM trip_counts t JOIN buses b ON b.id = t.bus_id;

-- Window LEAD/LAG: next stop and gap in minutes along each route
SELECT r.name AS route, s.name AS stop, rs.minutes_from_start,
       LEAD(s.name) OVER w AS next_stop,
       LEAD(rs.minutes_from_start) OVER w - rs.minutes_from_start AS minutes_to_next
FROM route_stops rs JOIN routes r ON r.id = rs.route_id JOIN stops s ON s.id = rs.stop_id
WINDOW w AS (PARTITION BY rs.route_id ORDER BY rs.seq);

-- Transactions / isolation / MVCC: two sessions, REPEATABLE READ snapshot
-- Session A:  BEGIN ISOLATION LEVEL REPEATABLE READ;  SELECT capacity FROM buses WHERE id=1;
-- Session B:  UPDATE buses SET capacity = 55 WHERE id = 1;  (commits instantly - readers never block writers)
-- Session A:  SELECT capacity FROM buses WHERE id=1;   -- still the old value (snapshot), then COMMIT.
-- Pessimistic lock when two admins edit one bus:  SELECT * FROM buses WHERE id=1 FOR UPDATE;

-- Index design: compare plans
EXPLAIN ANALYZE SELECT * FROM schedules WHERE bus_id = 1 AND departure_time > '07:00';

-- Vector search (pgvector): 5 nearest notices to notice #1 by cosine distance
SELECT id, title, embedding <=> (SELECT embedding FROM notices WHERE id = 1) AS dist
FROM notices WHERE id <> 1 ORDER BY dist LIMIT 5;
-- Hybrid: add full-text rank
-- SELECT id, title FROM notices WHERE to_tsvector('english', title||' '||body) @@ plainto_tsquery('delay') ORDER BY embedding <=> $1 LIMIT 5;
