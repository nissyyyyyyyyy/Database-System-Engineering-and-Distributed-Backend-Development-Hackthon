"""Load test:  locust -f loadtest/locustfile.py --host http://localhost:8000"""
from locust import HttpUser, between, task


class Student(HttpUser):
    wait_time = between(1, 3)

    def on_start(self):
        r = self.client.post("/auth/login", data={"username": "admin@campus.edu", "password": "admin12345"})
        self.h = {"Authorization": f"Bearer {r.json()['access_token']}"}

    @task(5)
    def arrivals(self):
        self.client.get("/student/arrivals", params={"stop": "Kukatpally", "direction": "in", "at": "07:00"}, headers=self.h)

    @task(2)
    def live(self):
        self.client.get("/student/live", headers=self.h)

    @task(1)
    def search(self):
        self.client.get("/student/notices/search", params={"q": "exam buses"}, headers=self.h)
