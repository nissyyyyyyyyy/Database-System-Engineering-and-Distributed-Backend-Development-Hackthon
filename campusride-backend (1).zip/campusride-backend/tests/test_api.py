import os

os.environ.update(DATABASE_URL="sqlite://", RATE_LIMIT_PER_MINUTE="100000", JWT_SECRET="test-secret-test-secret-test-secret-32",
                  SEED_DEMO_DATA="true")

import pytest
from fastapi.testclient import TestClient

from app.crowd import predict_crowd
from app.main import app


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def auth(c, email, pw):
    r = c.post("/auth/login", data={"username": email, "password": pw})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="module")
def admin(client):
    return auth(client, "admin@campus.edu", "admin12345")


@pytest.fixture(scope="module")
def student(client):
    client.post("/auth/register", json={"email": "stu@campus.edu", "full_name": "Test Student", "password": "password123"})
    return auth(client, "stu@campus.edu", "password123")


def test_health(client):
    assert client.get("/health").json()["status"] == "ok"


def test_requires_token(client):
    assert client.get("/buses").status_code == 401
    assert client.get("/buses", headers={"Authorization": "Bearer nope"}).status_code == 401


def test_register_login_me(client, student):
    me = client.get("/auth/me", headers=student).json()
    assert me["role"] == "student" and me["email"] == "stu@campus.edu"
    assert client.post("/auth/register", json={"email": "stu@campus.edu", "full_name": "X Y", "password": "password123"}).status_code == 409
    assert client.post("/auth/login", data={"username": "stu@campus.edu", "password": "wrong"}).status_code == 401


def test_rbac_student_cannot_write(client, student):
    r = client.post("/drivers", json={"name": "Nope Nope", "phone": "1234567"}, headers=student)
    assert r.status_code == 403
    assert client.get("/buses", headers=student).status_code == 200


def test_admin_fleet_crud(client, admin):
    d = client.post("/drivers", json={"name": "Test Driver", "phone": "9000000001"}, headers=admin).json()
    r = client.post("/routes", headers=admin, json={"name": "Test Line", "stops": [
        {"name": "Alpha", "minutes": 0}, {"name": "Beta", "minutes": 10}, {"name": "College Campus", "minutes": 20}]})
    assert r.status_code == 201
    route = r.json()
    bus = {"number": "TS-TEST-1", "capacity": 30, "route_id": route["id"], "driver_id": d["id"]}
    b = client.post("/buses", json=bus, headers=admin)
    assert b.status_code == 201
    assert client.post("/buses", json=bus, headers=admin).status_code == 409          # unique bus number
    s = client.post("/schedules", headers=admin, json={"bus_id": b.json()["id"], "departure_time": "09:00", "direction": "in"})
    assert s.status_code == 201
    assert client.delete(f"/routes/{route['id']}", headers=admin).status_code == 409   # route still has a bus
    assert client.delete(f"/buses/{b.json()['id']}", headers=admin).status_code == 204  # cascades schedules
    assert client.delete(f"/routes/{route['id']}", headers=admin).status_code == 204


def test_route_validation(client, admin):
    bad = {"name": "Bad", "stops": [{"name": "A", "minutes": 10}, {"name": "B", "minutes": 5}]}
    assert client.post("/routes", json=bad, headers=admin).status_code == 422


def test_arrivals_sorted_with_crowd(client, student):
    r = client.get("/student/arrivals", params={"stop": "Kukatpally", "direction": "in", "at": "06:00", "weekday": 1}, headers=student)
    rows = r.json()
    assert r.status_code == 200 and len(rows) >= 2
    assert [x["minutes_away"] for x in rows] == sorted(x["minutes_away"] for x in rows)
    assert all(x["crowd_level"] in {"Low", "Medium", "High"} for x in rows)


def test_reports_raise_prediction(client, student):
    p = {"stop": "Kukatpally", "direction": "in", "at": "06:00", "weekday": 1}
    first = client.get("/student/arrivals", params=p, headers=student).json()[0]
    for _ in range(3):
        assert client.post("/student/reports", json={"bus_id": first["bus_id"], "level": "packed"}, headers=student).status_code == 201
    after = next(x for x in client.get("/student/arrivals", params=p, headers=student).json() if x["bus_id"] == first["bus_id"])
    assert after["occupancy_pct"] > first["occupancy_pct"]
    assert client.post("/student/reports", json={"bus_id": 9999, "level": "ok"}, headers=student).status_code == 404


def test_notice_search_and_rag(client, admin, student):
    client.post("/student/notices", json={"title": "Suchitra road work", "body": "Buses are delayed near Suchitra because of road work."}, headers=admin)
    hits = client.get("/student/notices/search", params={"q": "delayed road work Suchitra"}, headers=student).json()
    assert hits and hits[0]["title"] == "Suchitra road work"
    assert client.post("/student/notices", json={"title": "xxx", "body": "yyyyy"}, headers=student).status_code == 403
    ans = client.get("/student/notices/ask", params={"q": "why are buses delayed"}, headers=student).json()
    assert ans["sources"]


def test_admin_analytics(client, admin, student):
    rows = client.get("/admin/analytics/trips", headers=admin).json()
    assert rows and rows[0]["rank"] == 1
    assert client.get("/admin/analytics/trips", headers=student).status_code == 403


def test_crowd_model():
    peak = predict_crowd(480, "in", 4, 5, 50, 1)["occupancy"]
    off = predict_crowd(840, "in", 4, 5, 50, 1)["occupancy"]
    weekend = predict_crowd(480, "in", 4, 5, 50, 6)["occupancy"]
    assert peak > off and peak > weekend
    assert predict_crowd(480, "in", 4, 5, 50, 1, exam_day=True)["occupancy"] > peak
    assert predict_crowd(480, "in", 4, 5, 50, 1, feedback_avg=1.0)["occupancy"] > peak


def test_website_is_served(client):
    r = client.get("/")
    assert r.status_code == 200 and "CampusRide" in r.text
    assert client.get("/health").status_code == 200   # API routes still win over the static mount
